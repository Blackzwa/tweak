
import React from 'react';
import { WebView } from 'react-native-webview';

export default function Trade() {
  return <WebView source={{ uri: 'https://www.tradingview.com/chart/' }} />;
}
