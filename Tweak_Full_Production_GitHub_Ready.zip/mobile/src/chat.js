
import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, Text } from 'react-native';
import io from 'socket.io-client';

const socket = io('http://localhost:5000');

export default function Chat() {
  const [msg, setMsg] = useState('');
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    socket.emit('joinRoom', 'global');
    socket.on('message', m => setMessages(prev => [...prev, m.text]));
  }, []);

  return (
    <View>
      <Text>{messages.join('\n')}</Text>
      <TextInput value={msg} onChangeText={setMsg} />
      <Button title="Send" onPress={() => socket.emit('message', { room: 'global', text: msg })} />
    </View>
  );
}
