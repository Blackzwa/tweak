
import React from 'react';
import { View, Button } from 'react-native';

export default function Profile() {
  return (
    <View>
      <Button title="Subscribe (Unlock Copy Trading)" />
    </View>
  );
}
