
import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Chat from './chat';
import Trade from './trade';
import Profile from './profile';

const Tab = createBottomTabNavigator();

export default function Tabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Community" component={Chat} />
      <Tab.Screen name="Trade" component={Trade} />
      <Tab.Screen name="Profile" component={Profile} />
    </Tab.Navigator>
  );
}
